package models;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;


@Entity
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String studentName;

    @Max(35)
    @Min(0)
    private int actividades;

    @Max(15)
    @Min(0)
    private int primerParcial;

    @Max(15)
    @Min(0)
    private int segundoParcial;

    @Max(35)
    @Min(0)
    private int examenFinal;

    private int total;

    // Getters y setters

    public void calculateTotal() {
        this.total = this.actividades + this.primerParcial + this.segundoParcial + this.examenFinal;
    }
}